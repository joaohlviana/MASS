import React from "react";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../components/ui/navigation-menu";
import { DivByAnima } from "./sections/DivByAnima/DivByAnima";
import { DivWrapperByAnima } from "./sections/DivWrapperByAnima";
import { FooterByAnima } from "./sections/FooterByAnima/FooterByAnima";
import { SectionByAnima } from "./sections/SectionByAnima";
import { SectionComponentNodeByAnima } from "./sections/SectionComponentNodeByAnima/SectionComponentNodeByAnima";
import { SectionWrapperByAnima } from "./sections/SectionWrapperByAnima";

export const ElementLight = (): JSX.Element => {
  // Navigation menu items data
  const navItems = [
    { text: "Home", isBold: true },
    { text: "ACOMPANHANTES", isBold: true },
    { text: "DÚVIDAS FREQUENTES", isBold: true },
    { text: "CONTATO", isBold: true },
    { text: "ANUNCIAR", isBold: true },
    { text: "NÃO CAIA EM GOLPES", isBold: true },
  ];

  return (
    <div className="relative w-full bg-londrinasexycombrwhite-mine-shaft">
      <SectionByAnima />
      <SectionWrapperByAnima />
      <DivWrapperByAnima />
      <DivByAnima />
      <SectionComponentNodeByAnima />
      <FooterByAnima />

      <header className="flex flex-col w-full items-center pt-1.5 pb-[7px] px-0 sticky top-0 left-0 z-50 bg-londrinasexycombrblack-125 border-b border-[#e60d4a] shadow-[0px_0px_18px_#e60d4a]">
        <div className="relative max-w-[1200px] w-full h-[78.83px]">
          {/* Logo */}
          <div className="absolute w-[204px] h-[57px] top-0 left-0 bg-[url(/link---acompanhantes-em-londrina---londrina-sexy.png)] bg-cover bg-[50%_50%]" />

          {/* Navigation MenuIcon */}
          <NavigationMenu className="absolute top-[7px] left-[204px]">
            <NavigationMenuList className="flex w-[900px] items-start justify-end gap-6 pl-[49.98px] pr-3 pt-[13px] pb-3.5">
              {navItems.map((item, index) => (
                <NavigationMenuItem key={index}>
                  <NavigationMenuLink
                    className={`relative w-fit mt-[-1.00px] font-roboto ${item.isBold ? "font-bold" : "font-normal"} text-londrinasexycombrsweet-pink text-base tracking-[0] leading-[normal] whitespace-nowrap`}
                  >
                    {item.text}
                  </NavigationMenuLink>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>

          {/* Location Bar */}
          <div className="flex flex-col w-[1220px] items-start px-3 py-[5px] absolute top-[63px] -left-2.5">
            <div className="absolute w-[1220px] h-[22px] top-0 left-0 bg-londrinasexycombrred-ribbon rounded-[4px_4px_0px_0px]" />
            <div className="relative w-fit mt-[-1.00px] font-londrinasexy-com-br-semantic-heading-1 font-[number:var(--londrinasexy-com-br-semantic-heading-1-font-weight)] text-londrinasexycombrwhite text-[length:var(--londrinasexy-com-br-semantic-heading-1-font-size)] tracking-[var(--londrinasexy-com-br-semantic-heading-1-letter-spacing)] leading-[var(--londrinasexy-com-br-semantic-heading-1-line-height)] whitespace-nowrap [font-style:var(--londrinasexy-com-br-semantic-heading-1-font-style)]">
              Acompanhantes Londrina / PR
            </div>
          </div>

          {/* SearchIcon Icon */}
          <div className="absolute top-[7px] left-[1108px] p-3 flex items-center justify-center">
            <div className="relative">
              <div className="relative w-[18px] h-[18px] rounded-[9px] border-[3px] border-solid border-white" />
              <div className="absolute w-[3px] h-[11px] top-[16px] left-[16px] bg-londrinasexycombrwhite rounded -rotate-45" />
            </div>
          </div>

          {/* MenuIcon Icon */}
          <div className="absolute top-[9px] left-[1156px] p-[11px]">
            <div className="flex flex-col gap-1">
              <div className="w-[25px] h-[3px] bg-londrinasexycombrwhite rounded-md" />
              <div className="w-[25px] h-[3px] bg-londrinasexycombrwhite rounded-md" />
              <div className="w-[25px] h-[3px] bg-londrinasexycombrwhite rounded-md" />
            </div>
          </div>
        </div>
      </header>
    </div>
  );
};
