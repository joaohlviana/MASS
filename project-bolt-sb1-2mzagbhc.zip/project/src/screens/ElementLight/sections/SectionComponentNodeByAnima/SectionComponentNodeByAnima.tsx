import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

// Define the profile data structure
interface ProfileData {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
  hasFlag?: boolean;
}

export const SectionComponentNodeByAnima = (): JSX.Element => {
  // Data for all profiles
  const profiles: ProfileData[] = [
    {
      id: 1,
      name: "Sarah Cash",
      description:
        "Morena de primeira classe pela primeira vez. Venha viver...",
      imageUrl: "/ver-perfil-da-sarah-cash-2.png",
      hasFlag: true,
    },
    {
      id: 2,
      name: "Victoria",
      description:
        "Morena Ninfeta primeira vez. Sou Victoria, atendimento sem...",
      imageUrl: "/ver-perfil-da-victoria-2.png",
    },
    {
      id: 3,
      name: "Eloísa Queiroz",
      description: "Loirinha de alto nível primeira vez no Londrina...",
      imageUrl: "/ver-perfil-da-elo-sa-queiroz-2.png",
      hasFlag: true,
    },
    {
      id: 4,
      name: "Lara Fernandes",
      description:
        "Soda, limonada gostosa e geladinha! Neste calor precisamos...",
      imageUrl: "/ver-perfil-da-lara-fernandes-1.png",
    },
    {
      id: 5,
      name: "Isabele Miloch",
      description: "Isabele Miloch delícia espetacular! Rosto angelical e...",
      imageUrl: "/ver-perfil-da-isabele-miloch-1.png",
    },
    {
      id: 6,
      name: "Jaque Ribeiro",
      description: "O desejo de muitos, privilégio de poucos. Gata de...",
      imageUrl: "/ver-perfil-da-jaque-ribeiro-1.png",
      hasFlag: true,
    },
    {
      id: 7,
      name: "Mirella",
      description: "Belíssima e quente Curta temporada. Sou uma garota...",
      imageUrl: "/ver-perfil-da-mirella-2.png",
      hasFlag: true,
    },
    {
      id: 8,
      name: "Kelly",
      description: "Exclusiva! Para homens de bom gosto e que procuram...",
      imageUrl: "/ver-perfil-da-kelly-3.png",
      hasFlag: true,
    },
    {
      id: 9,
      name: "Amanda Medeiros",
      description:
        "Acompanhante de alto nível para homens exigentes. Amanda...",
      imageUrl: "/ver-perfil-da-amanda-medeiros-2.png",
      hasFlag: true,
    },
    {
      id: 10,
      name: "Jennifer",
      description: " Curta temporada em Londrina. Morena mato-grossense,...",
      imageUrl: "/ver-perfil-da-jennifer-1.png",
      hasFlag: true,
    },
    {
      id: 11,
      name: "Samanta",
      description: "Levo você no auge do Prazer! Maranhense fogosa, adoro...",
      imageUrl: "/ver-perfil-da-samanta-2.png",
    },
    {
      id: 12,
      name: "Hellen Cristina",
      description: "Mulherão de 1.80 m, safada estilo namoradinha, prazer...",
      imageUrl: "/ver-perfil-da-hellen-cristina-1.png",
      hasFlag: true,
    },
    {
      id: 13,
      name: "Carla",
      description: "Carla , Novinha, massagem eróticas ! Olá me chamo Carla...",
      imageUrl: "/ver-perfil-da-carla-1.png",
    },
    {
      id: 14,
      name: "Bruna",
      description: "Loira Delícia cavala passando por Londrina. Uma loira...",
      imageUrl: "/ver-perfil-da-bruna-2.png",
      hasFlag: true,
    },
    {
      id: 15,
      name: "Eloah",
      description:
        "Garota Sexy e sedutora! Bonita e sensual, dona de um corpo...",
      imageUrl: "/ver-perfil-da-eloah-1.png",
    },
    {
      id: 16,
      name: "Lavínia",
      description:
        "A sua melhor escolha. Olá, sou uma universitária educada...",
      imageUrl: "/ver-perfil-da-lav-nia-1.png",
    },
    {
      id: 17,
      name: "Natasha",
      description: "Sou Natasha ! Salas aquecidas. Faço Massagem Eróticas...",
      imageUrl: "/ver-perfil-da-natasha-1.png",
    },
    {
      id: 18,
      name: "Vick",
      description: "Olá, sou a Vick, faço massagens eróticas! Especialista...",
      imageUrl: "/ver-perfil-da-vick-1.png",
    },
    {
      id: 19,
      name: "Julia",
      description: "Olá amores, primeira vez na cidade! Olá amores sou...",
      imageUrl: "/ver-perfil-da-julia-1.png",
    },
    {
      id: 20,
      name: "Andressa Medeiros",
      description: "Morena acima de média em Londrina. Sou uma acompanhante...",
      imageUrl: "/ver-perfil-da-andressa-medeiros-1.png",
    },
    {
      id: 21,
      name: "Helen",
      description: " Loira é uma profissional! Ela é a companhia ideal para...",
      imageUrl: "/ver-perfil-da-helen-1.png",
    },
    {
      id: 22,
      name: "Alice",
      description: "Atendimento alto padrão. Muito fogosa e carinhosa. Olá...",
      imageUrl: "/ver-perfil-da-alice-2.png",
      hasFlag: true,
    },
    {
      id: 23,
      name: "Rafaella",
      description: "Rafaella gata de alto padrão. Olla ,me chamo Rafaella ,...",
      imageUrl: "/ver-perfil-da-rafaella-1.png",
      hasFlag: true,
    },
    {
      id: 24,
      name: "Cacau Mello",
      description: "Morena toda sexy e gostosa! Olá meus amores, tenho 22...",
      imageUrl: "/ver-perfil-da-cacau-mello-1.png",
    },
    {
      id: 25,
      name: "Susy",
      description: "Loira com rosto angelical! Olá meus amores,sou uma...",
      imageUrl: "/ver-perfil-da-susy-1.png",
    },
  ];

  return (
    <section className="w-full max-w-[1200px] mx-auto py-8">
      <h2 className="font-londrinasexy-com-br-semantic-heading-2-upper text-londrinasexycombrfroly text-[length:var(--londrinasexy-com-br-semantic-heading-2-upper-font-size)] tracking-[var(--londrinasexy-com-br-semantic-heading-2-upper-letter-spacing)] leading-[var(--londrinasexy-com-br-semantic-heading-2-upper-line-height)] mb-6">
        ANUNCIOS RECENTES
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
        {profiles.map((profile) => (
          <Card
            key={profile.id}
            className="overflow-hidden border-0 rounded-md"
          >
            <div className="relative">
              <div
                className="h-[320px] bg-cover bg-center rounded-t-md"
                style={{ backgroundImage: `url(${profile.imageUrl})` }}
              />
              {profile.hasFlag && (
                <div className="absolute top-1 left-1">
                  <div className="flex items-center">
                    <img
                      className="w-[21.34px] h-[15px]"
                      alt="Flag"
                      src="/image.svg"
                    />
                  </div>
                </div>
              )}
            </div>
            <CardContent className="p-2">
              <div className="font-['Roboto',Helvetica] text-base">
                <span className="font-bold text-[#fa99ab] block">
                  {profile.name}
                </span>
                <span className="text-[#f0f0f0]">{profile.description}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
