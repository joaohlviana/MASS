import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";
import { ScrollArea, ScrollBar } from "../../../../components/ui/scroll-area";

// Define the story data structure
interface Story {
  id: string;
  name: string;
  profileImage: string;
  storyImage: string;
}

// Create an array of story data
const stories: Story[] = [
  {
    id: "1",
    name: "KELLY SOUZA",
    profileImage: "/ver-story-de-kelly-souza.png",
    storyImage: "/picture---ver-acompanhante-kelly-souza.png",
  },
  {
    id: "2",
    name: "ALICE",
    profileImage: "/ver-story-de-alice.png",
    storyImage: "/picture---ver-acompanhante-alice.png",
  },
  {
    id: "3",
    name: "BRUNA",
    profileImage: "/ver-story-de-bruna.png",
    storyImage: "/picture---ver-acompanhante-bruna.png",
  },
  {
    id: "4",
    name: "SHEYLA CHRISTINA",
    profileImage: "/ver-story-de-sheyla-christina.png",
    storyImage: "/picture---ver-acompanhante-sheyla-christina.png",
  },
  {
    id: "5",
    name: "LUNA MAYA",
    profileImage: "/ver-story-de-luna-maya.png",
    storyImage: "/picture---ver-acompanhante-luna-maya.png",
  },
  {
    id: "6",
    name: "ISABELE MILOCH",
    profileImage: "/ver-story-de-isabele-miloch.png",
    storyImage: "/picture---ver-acompanhante-isabele-miloch.png",
  },
  {
    id: "7",
    name: "HELEN",
    profileImage: "/ver-story-de-helen.png",
    storyImage: "/picture---ver-acompanhante-helen.png",
  },
  {
    id: "8",
    name: "CARLA",
    profileImage: "/ver-story-de-carla.png",
    storyImage: "/picture---ver-acompanhante-carla.png",
  },
  {
    id: "9",
    name: "SAMANTA",
    profileImage: "/ver-story-de-samanta.png",
    storyImage: "/picture---ver-acompanhante-samanta.png",
  },
  {
    id: "10",
    name: "JENNIFER",
    profileImage: "/ver-story-de-jennifer.png",
    storyImage: "/picture---ver-acompanhante-jennifer.png",
  },
  {
    id: "11",
    name: "JAQUE RIBEIRO",
    profileImage: "/ver-story-de-jaque-ribeiro.png",
    storyImage: "/picture---ver-acompanhante-jaque-ribeiro.png",
  },
  {
    id: "12",
    name: "AMANDA MEDEIROS",
    profileImage: "/ver-story-de-amanda-medeiros.png",
    storyImage: "/picture---ver-acompanhante-amanda-medeiros.png",
  },
];

export const SectionByAnima = (): JSX.Element => {
  return (
    <section className="relative w-full pt-[22px] pb-[23px] bg-londrinasexycombrmine-shaft border-b border-[#ffffff12]">
      <div className="absolute w-full h-[341px] top-0 left-0 bg-londrinasexycombrwhite-02 shadow-[0px_20px_30px_-20px_#0000004c]" />

      <div className="relative mx-auto max-w-[1200px] h-[297.31px]">
        <h2 className="text-londrinasexycombrfroly font-londrinasexy-com-br-semantic-heading-2-upper font-[number:var(--londrinasexy-com-br-semantic-heading-2-upper-font-weight)] text-[length:var(--londrinasexy-com-br-semantic-heading-2-upper-font-size)] tracking-[var(--londrinasexy-com-br-semantic-heading-2-upper-letter-spacing)] leading-[var(--londrinasexy-com-br-semantic-heading-2-upper-line-height)] whitespace-nowrap [font-style:var(--londrinasexy-com-br-semantic-heading-2-upper-font-style)]">
          STORIES LONDRINA SEXY
        </h2>

        <ScrollArea className="w-full h-[270px] mt-[27px]">
          <div className="flex space-x-2.5 px-2.5">
            {stories.map((story) => (
              <Card
                key={story.id}
                className="w-[184.5px] rounded-[7px] border-none bg-transparent"
              >
                <CardContent className="p-0 pb-1.5">
                  <div className="relative">
                    <div
                      className="w-full h-[264.31px] rounded-[7px] bg-cover bg-center"
                      style={{ backgroundImage: `url(${story.storyImage})` }}
                    />

                    <div className="absolute w-[57px] top-2 left-2 bg-londrinasexycombrwhite-02 rounded-[28.26px] p-px overflow-hidden border border-solid border-[#e60d4a] shadow-[1px_1px_5px_#00000080]">
                      <div
                        className="w-full h-[54.52px] rounded-[7px] bg-cover bg-center"
                        style={{
                          backgroundImage: `url(${story.profileImage})`,
                        }}
                      />
                    </div>

                    <div className="absolute bottom-[23px] left-2 [text-shadow:1px_1px_3px_#00000066] font-bold text-londrinasexycombrwhite text-[13.4px] tracking-[0] leading-[normal] underline whitespace-nowrap">
                      {story.name}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
    </section>
  );
};
