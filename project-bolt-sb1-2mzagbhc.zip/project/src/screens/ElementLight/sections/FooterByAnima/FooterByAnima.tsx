import React from "react";
import { Separator } from "../../../../components/ui/separator";

// Define categories for the footer navigation
const categories = [
  "LOIRAS",
  "MORENAS",
  "NEGRAS/MULATAS",
  "RUIVAS",
  "JAPONESAS/MESTIÇAS",
  "MESTIÇAS",
  "MOTÉIS",
];

// Define content sections for better organization
const contentSections = [
  {
    title:
      "PRIMEIROS PASSOS PARA CONTRATAR UMA ACOMPANHANTE OU GAROTA DE PROGRAMA EM LONDRINA",
    paragraphs: [
      <>
        Você que nunca saiu ou contratou{" "}
        <strong>acompanhantes em Londrina</strong>, não se preocupe, aqui você
        pode encontrar um esclarecimento de como proceder de forma objetiva
        <br />
        para ter os serviços de uma garota de alto nível.
      </>,
      <>
        Quem quer sair com uma <strong>acompanhante em Londrina</strong> do site
        Londrina Sexy, não pode ser menor de idade. O usuário deve escolher e
        conversar detalhadamente com
        <br />
        as acompanhantes para não haver dúvida alguma sobre o encontro a ser
        agendado.
      </>,
      "Cada acompanhante do Londrina Sexy tem um atendimento diferenciado, sendo diversificado, não existindo um padrão de atendimento ou precificação, mesmo sobre os\nserviços a serem prestados ou o tempo em que o cliente desfrutará junto com a acompanhante.",
      <>
        O site Londrina sexy limita-se apenas a publicar os anúncios das{" "}
        <strong>acompanhantes de Londrina</strong> e região, por isso, somos um
        classificado de anúncios de serviços{" "}
        <strong>para maiores de 18 anos</strong>.
      </>,
      <>
        A <strong>garota de programa paga seu anúncio</strong>, este site não
        cobra comissões ou taxas referentes a quaisquer serviços prestados pelas
        mesmas com seus clientes.
      </>,
      <>
        O site{" "}
        <strong>
          Londrina sexy não interfere em quaisquer atividades ou relacionamentos
          da anunciante
        </strong>{" "}
        e não se responsabiliza entre a relação da mesma com seus
        <br />
        clientes.
      </>,
      "Toda a negociação e/ou contratação é feita diretamente com a GP – Garota de Programa e não com este site.",
      "As fotos e dados nos anúncios são de única e exclusiva responsabilidade da garota, quaisquer dúvidas sobre o anúncio recomendamos entrar em contato diretamente\ncom a acompanhante escolhida.",
    ],
  },
  {
    title: "Referência no Paraná, o Londrina Sexy é reconhecido nacionalmente",
    paragraphs: [
      <>
        Diferente de casas de massagem ou agência de acompanhantes, o
        LondrinaSexy publica anúncios das <strong>acompanhantes de Luxo</strong>{" "}
        e alto nível de Londrina, com fotos
        <br />
        reais, priorizando a transparência e ensaios fotográficos originais e
        reais das garotas de Londrina.
      </>,
      "Todas as gatas de alto nível do Londrina Sexy comprovam maioridade e existem.",
      <>
        O Londrina Sexy é o <strong>site número 1</strong> de Londrina, o mais
        antigo da cidade, reconhecido pela conduta séria e transparente sobre as{" "}
        <strong>acompanhantes de Londrina e Região</strong>.
      </>,
      <>
        Quando falamos em <strong>acompanhantes de Luxo</strong> e Alto nível,
        nos referimos a gatas top, inteligentes, lindas, belas garotas, que se
        cuidam e são extremamente vaidosas,
        <br />
        muitas são inclusive universitárias em Londrina e em outras cidades,
        pois muitas garotas universitárias fazem pequenas e curtas temporadas em
        Londrina.
      </>,
      "Outra boa forma de sair e marcar um encontro com uma acompanhante é através de uma indicação de um amigo, passando credibilidade e confiança. Cada garota tem\nem sua página a opção de compartilhamento.",
      "Portanto não deixe de compartilhar com um amigo uma garota que você gostou muito, e acredita que lhe prestou um ótimo serviço.",
      "O importante é combinar tudo antes de marcar o encontro, esclareça todas e quaisquer dúvidas sobre preço, tempo e todos os outros detalhes.",
    ],
  },
  {
    title: "O primeiro e tradicional site de acompanhantes de Londrina",
    paragraphs: [
      <>
        O LondrinaSexy é o<strong> site de acompanhantes</strong> mais antigo, o
        primeiro da cidade de Londrina, priorizando sempre a qualidade e nível
        das acompanhantes, para oferecer o<br />
        melhor serviço de classificados de acompanhantes online sempre que
        possível.
      </>,
      <>
        As mais <strong>lindas mulheres de Londrina</strong> e região publicam
        seus anúncios com fotos neste site, que também é conhecido em todo o
        Brasil.
      </>,
      <>
        As lindas <strong>garotas de programas de luxo</strong> de várias
        cidades do Brasil fazem temporadas curtas em Londrina anunciando no
        Londrina Sexy.
      </>,
      "Há quase 20 anos no ar, somos a preferência tanto de homens com alto poder aquisitivo, executivos, como também outros perfis, com menos poder financeiro.",
      "Não perca a oportunidade de desfrutar da companhia de uma bela gata Book Rosa, existem inúmeras opções, desde as lindas loiras como também as lindas negras, as\nmorenas e as japonesas/Mestiças.",
    ],
  },
  {
    title: "Confiança e Credibilidade",
    paragraphs: [
      <>
        Ao longo dos anos conquistamos a credibilidade, o LondrinaSexy é uma
        marca quando o assunto é acompanhante ou{" "}
        <strong>garotas de programa em Londrina</strong>, ou "{" "}
        <strong>Escort Girls</strong> " Termo utilizado em muitos países.
      </>,
      "Cada perfil anunciado é verificado e real. Estamos sempre em busca das melhores atualizações sobre o tema, sempre para oferecer a melhor plataforma de website,\ndinâmico, atual e de fácil usabilidade.",
      "Este portal ficou conhecido não somente em Londrina, mas também em todo território Nacional como o site das acompanhantes bonitas, são para todos os estilos:\ngarotas universitárias, das gostosas saradas, as perfeitinhas, estilo modelo, as coroas top, namoradinhas novinhas, estilo ninfetas, patricinhas e vários outros estilos.",
    ],
  },
];

export const FooterByAnima = (): JSX.Element => {
  return (
    <footer className="flex flex-col w-full items-center gap-[30px] pt-8 pb-0 px-2.5 bg-londrinasexycombrblack-125 border-t border-[#ffffff12]">
      <div className="relative max-w-[1200px] w-full">
        {/* Logo */}
        <div className="flex flex-col h-[57px] items-start mb-6">
          <div className="relative w-[204px] h-[56.83px] bg-[url(/acompanhantes-londrina---pr.png)] bg-cover bg-[50%_50%]" />
        </div>

        {/* Content Sections */}
        {contentSections.map((section, index) => (
          <div key={index} className="mb-8">
            {section.title && (
              <h2
                className={`text-londrinasexycombrwhite text-lg font-bold mb-4 ${index === 0 ? "text-[19.2px] [text-shadow:0px_2px_3px_#00000080]" : ""}`}
              >
                {section.title}
              </h2>
            )}
            <div className="space-y-4">
              {section.paragraphs.map((paragraph, pIndex) => (
                <p
                  key={pIndex}
                  className="text-londrinasexycombrwhite text-base leading-tight"
                >
                  {paragraph}
                </p>
              ))}
            </div>
          </div>
        ))}

        {/* Social Media Section */}
        <div className="mt-6">
          <h3 className="text-londrinasexycombrwhite text-[19.2px] text-center mb-4 [text-shadow:0px_2px_3px_#00000080]">
            LONDRINASEXY NAS REDES
          </h3>
          <div className="flex justify-end">
            <div className="flex items-center justify-center w-[59px] h-[58px] rounded-[38px] bg-londrinasexycombrred-ribbon bg-opacity-50">
              <img
                className="w-[26px] h-[26px]"
                alt="Social media icon"
                src="/image-71.svg"
              />
            </div>
          </div>
        </div>
      </div>

      <Separator className="w-full bg-[#ffffff12]" />

      {/* Footer Navigation */}
      <div className="flex flex-col w-full items-center gap-[21px] py-8 bg-londrinasexycombrblack-10">
        <div className="flex flex-wrap justify-center gap-1">
          {categories.map((category, index) => (
            <div
              key={index}
              className="inline-flex items-center justify-center py-3 px-3"
            >
              <span className="text-londrinasexycombrsweet-pink text-sm [text-shadow:1px_1px_3px_#000000cc]">
                {category}
              </span>
            </div>
          ))}
        </div>

        <div className="text-londrinasexycombrwhite text-xs text-center">
          © 2025 - TODOS OS DIREITOS RESERVADOS LONDRINA SEXY
        </div>
      </div>
    </footer>
  );
};
