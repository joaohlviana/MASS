import React from "react";
import { Card, CardContent, CardFooter } from "../../../../components/ui/card";

export const SectionWrapperByAnima = (): JSX.Element => {
  // Profile data for mapping
  const profiles = [
    {
      id: 1,
      name: "AMANDA MEDEIROS",
      image: "/ver-perfil-da-amanda-medeiros.png",
      hasIcon: true,
    },
    {
      id: 2,
      name: "MELISSA MESTIÇA",
      image: "/ver-perfil-da-melissa-mesti-a.png",
      hasIcon: true,
    },
    {
      id: 3,
      name: "VICTORIA",
      image: "/ver-perfil-da-victoria.png",
      hasIcon: false,
    },
    {
      id: 4,
      name: "ALICE",
      image: "/ver-perfil-da-alice.png",
      hasIcon: true,
    },
    {
      id: 5,
      name: "FERNANDA",
      image: "/ver-perfil-da-fernanda.png",
      hasIcon: true,
    },
    {
      id: 6,
      name: "SARAH CASH",
      image: "/ver-perfil-da-sarah-cash.png",
      hasIcon: true,
    },
    {
      id: 7,
      name: "KELLY",
      image: "/ver-perfil-da-kelly.png",
      hasIcon: true,
    },
    {
      id: 8,
      name: "BRUNA",
      image: "/ver-perfil-da-bruna.png",
      hasIcon: true,
    },
    {
      id: 9,
      name: "SAMANTA",
      image: "/ver-perfil-da-samanta.png",
      hasIcon: false,
    },
    {
      id: 10,
      name: "MARINA",
      image: "/ver-perfil-da-marina.png",
      hasIcon: false,
    },
  ];

  return (
    <section className="w-full max-w-[1200px] mx-auto py-8">
      <h2 className="font-londrinasexy-com-br-semantic-heading-2-upper text-londrinasexycombrfroly text-[length:var(--londrinasexy-com-br-semantic-heading-2-upper-font-size)] tracking-[var(--londrinasexy-com-br-semantic-heading-2-upper-letter-spacing)] leading-[var(--londrinasexy-com-br-semantic-heading-2-upper-line-height)] mb-5">
        TOP GATAS
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2.5">
        {profiles.map((profile) => (
          <Card
            key={profile.id}
            className="w-full bg-londrinasexycombrmine-shaft rounded-[11px] shadow-[1px_1px_0px_#0000001a] overflow-hidden"
          >
            <CardContent className="p-2">
              <div className="relative">
                <div
                  className="w-full h-[323px] rounded-[5px] bg-cover bg-center"
                  style={{ backgroundImage: `url(${profile.image})` }}
                />

                {profile.hasIcon && (
                  <div className="absolute top-[5px] left-[5px] w-[25px] h-[15px]">
                    <div className="flex flex-col w-[25px] h-[15px] items-start pl-0 pr-[3.66px] py-0">
                      <img
                        className="w-[21.34px] h-[15px]"
                        alt="Image"
                        src="/image.svg"
                      />
                    </div>
                  </div>
                )}
              </div>
            </CardContent>

            <CardFooter className="p-2.5 pt-0">
              <h3 className="font-['Roboto',Helvetica] font-bold text-londrinasexycombrgallery text-base">
                {profile.name}
              </h3>
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  );
};
