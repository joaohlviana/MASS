import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";

export const DivWrapperByAnima = (): JSX.Element => {
  // Profile data for mapping
  const profiles = [
    {
      id: 1,
      name: "Eloísa Queiroz",
      description: "Loirinha de alto nível primeira vez no Londrina...",
      image: "/ver-perfil-da-elo-sa-queiroz.png",
      hasIcon: true,
    },
    {
      id: 2,
      name: "Sheyla Christina",
      description: "I'm Juicy!!!!!! Descubra uma experiência única com uma...",
      image: "/ver-perfil-da-sheyla-christina.png",
      hasIcon: true,
    },
    {
      id: 3,
      name: "Andrea",
      description: "Massagem alto nível com finalização. Atendendo há 4...",
      image: "/ver-perfil-da-andrea.png",
      hasIcon: false,
    },
    {
      id: 4,
      name: "Kelly",
      description: "Exclusiva! Para homens de bom gosto e que procuram...",
      image: "/ver-perfil-da-kelly-1.png",
      hasIcon: true,
    },
    {
      id: 5,
      name: "Mayumi Bianchi",
      description:
        "Mesticinha gata. Olá sou a MAYUMI uma moreninha mignon de...",
      image: "/ver-perfil-da-mayumi-bianchi.png",
      hasIcon: false,
    },
    {
      id: 6,
      name: "Luna Maya",
      description:
        "A companhia ideal para homens que procuram uma prazerosa...",
      image: "/ver-perfil-da-luna-maya.png",
      hasIcon: false,
    },
    {
      id: 7,
      name: "Maria Fernandez",
      description: "Magrinha Top em Londrina. Oi, meu amor, tudo bem? Me...",
      image: "/ver-perfil-da-maria-fernandez.png",
      hasIcon: true,
    },
    {
      id: 8,
      name: "Mirella",
      description: "Belíssima e quente Curta temporada. Sou uma garota...",
      image: "/ver-perfil-da-mirella.png",
      hasIcon: true,
    },
  ];

  return (
    <section className="relative w-full max-w-[1200px] mx-auto my-8 px-4">
      <h2 className="font-londrinasexy-com-br-semantic-heading-2-upper text-londrinasexycombrfroly text-[length:var(--londrinasexy-com-br-semantic-heading-2-upper-font-size)] tracking-[var(--londrinasexy-com-br-semantic-heading-2-upper-letter-spacing)] leading-[var(--londrinasexy-com-br-semantic-heading-2-upper-line-height)] mb-6">
        DESTAQUES
      </h2>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
        {profiles.map((profile) => (
          <Card
            key={profile.id}
            className="border-0 overflow-hidden bg-transparent"
          >
            <div className="relative">
              <div
                className="h-[200px] rounded-[7px] bg-cover bg-center"
                style={{ backgroundImage: `url(${profile.image})` }}
              />
              {profile.hasIcon && (
                <div className="absolute top-[5px] left-[5px]">
                  <img
                    className="w-[21.34px] h-[15px]"
                    alt="Image"
                    src="/image.svg"
                  />
                </div>
              )}
            </div>
            <CardContent className="pt-1.5 pb-1 px-0.5">
              <div className="[font-family:'Roboto',Helvetica] text-base leading-4">
                <span className="font-bold text-[#fa99ab] block">
                  {profile.name}
                </span>
                <span className="text-[#f0f0f0] block mt-1">
                  {profile.description}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="w-full h-[21px] mt-4 bg-londrinasexycombrwhite-02 rounded-[0px_0px_30px_30px] border-b border-[#ffffff0d] shadow-[inset_0px_-7px_7px_-5px_#00000026]" />
    </section>
  );
};
