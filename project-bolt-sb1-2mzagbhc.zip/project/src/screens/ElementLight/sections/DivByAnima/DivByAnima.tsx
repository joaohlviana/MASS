import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Card, CardContent } from "../../../../components/ui/card";

// Profile data for mapping
const profiles = [
  {
    id: 1,
    name: "Sarah Cash",
    description: "Morena de primeira classe pela primeira vez. Venha viver...",
    image: "/ver-perfil-da-sarah-cash-1.png",
    hasVideo: true,
  },
  {
    id: 2,
    name: "Victoria",
    description:
      "Morena Ninfeta primeira vez. Sou Victoria, atendimento sem...",
    image: "/ver-perfil-da-victoria-1.png",
    hasVideo: false,
  },
  {
    id: 3,
    name: "Eloísa Queiroz",
    description: "Loirinha de alto nível primeira vez no Londrina...",
    image: "/ver-perfil-da-elo-sa-queiroz-1.png",
    hasVideo: true,
  },
  {
    id: 4,
    name: "Lara Fernandes",
    description:
      "Soda, limonada gostosa e geladinha! Neste calor precisamos...",
    image: "/ver-perfil-da-lara-fernandes.png",
    hasVideo: false,
  },
  {
    id: 5,
    name: "Isabele Miloch",
    description: "Isabele Miloch delícia espetacular! Rosto angelical e...",
    image: "/ver-perfil-da-isabele-miloch.png",
    hasVideo: false,
  },
  {
    id: 6,
    name: "Jaque Ribeiro",
    description: "O desejo de muitos, privilégio de poucos. Gata de...",
    image: "/ver-perfil-da-jaque-ribeiro.png",
    hasVideo: true,
  },
  {
    id: 7,
    name: "Mirella",
    description: "Belíssima e quente Curta temporada. Sou uma garota...",
    image: "/ver-perfil-da-mirella-1.png",
    hasVideo: true,
  },
  {
    id: 8,
    name: "Kelly",
    description: "Exclusiva! Para homens de bom gosto e que procuram...",
    image: "/ver-perfil-da-kelly-2.png",
    hasVideo: true,
  },
  {
    id: 9,
    name: "Amanda Medeiros",
    description: "Acompanhante de alto nível para homens exigentes. Amanda...",
    image: "/ver-perfil-da-amanda-medeiros-1.png",
    hasVideo: true,
  },
  {
    id: 10,
    name: "Fernanda",
    description: "Sou atenciosa e carinhosa! Olá, venha me conhecer teremos...",
    image: "/ver-perfil-da-fernanda-1.png",
    hasVideo: true,
  },
  {
    id: 11,
    name: "Jennifer",
    description: " Curta temporada em Londrina. Morena mato-grossense,...",
    image: "/ver-perfil-da-jennifer.png",
    hasVideo: true,
  },
  {
    id: 12,
    name: "Samanta",
    description: "Levo você no auge do Prazer! Maranhense fogosa, adoro...",
    image: "/ver-perfil-da-samanta-1.png",
    hasVideo: false,
  },
  {
    id: 13,
    name: "Hellen Cristina",
    description: "Mulherão de 1.80 m, safada estilo namoradinha, prazer...",
    image: "/ver-perfil-da-hellen-cristina.png",
    hasVideo: true,
  },
  {
    id: 14,
    name: "Carla",
    description: "Carla , Novinha, massagem eróticas ! Olá me chamo Carla...",
    image: "/ver-perfil-da-carla.png",
    hasVideo: false,
  },
  {
    id: 15,
    name: "Bruna",
    description: "Loira Delícia cavala passando por Londrina. Uma loira...",
    image: "/ver-perfil-da-bruna-1.png",
    hasVideo: true,
  },
  {
    id: 16,
    name: "Eloah",
    description:
      "Garota Sexy e sedutora! Bonita e sensual, dona de um corpo...",
    image: "/ver-perfil-da-eloah.png",
    hasVideo: false,
  },
  {
    id: 17,
    name: "Lavínia",
    description: "A sua melhor escolha. Olá, sou uma universitária educada...",
    image: "/ver-perfil-da-lav-nia.png",
    hasVideo: false,
  },
  {
    id: 18,
    name: "Natasha",
    description: "Sou Natasha ! Salas aquecidas. Faço Massagem Eróticas...",
    image: "/ver-perfil-da-natasha.png",
    hasVideo: false,
  },
  {
    id: 19,
    name: "Melissa Mestiça",
    description: "  Linda Mestiça sedutora, recém chegada. Olá a...",
    image: "/ver-perfil-da-melissa-mesti-a-1.png",
    hasVideo: true,
  },
  {
    id: 20,
    name: "Vick",
    description: "Olá, sou a Vick, faço massagens eróticas! Especialista...",
    image: "/ver-perfil-da-vick.png",
    hasVideo: false,
  },
  {
    id: 21,
    name: "Julia",
    description: "Olá amores, primeira vez na cidade! Olá amores sou...",
    image: "/ver-perfil-da-julia.png",
    hasVideo: false,
  },
  {
    id: 22,
    name: "Andressa Medeiros",
    description: "Morena acima de média em Londrina. Sou uma acompanhante...",
    image: "/ver-perfil-da-andressa-medeiros.png",
    hasVideo: false,
  },
  {
    id: 23,
    name: "Mariana",
    description: "Que bom ter você no meu perfil de acompanhante. Mariana...",
    image: "/ver-perfil-da-mariana.png",
    hasVideo: false,
  },
  {
    id: 24,
    name: "Cacau",
    description: "Extrovertida e sexy! Sou uma morena extrovertida e...",
    image: "/ver-perfil-da-cacau.png",
    hasVideo: true,
  },
  {
    id: 25,
    name: "Helen",
    description: " Loira é uma profissional! Ela é a companhia ideal para...",
    image: "/ver-perfil-da-helen.png",
    hasVideo: false,
  },
  // Additional profiles would continue here
  {
    id: 26,
    name: "Alice",
    description: "Atendimento alto padrão. Muito fogosa e carinhosa. Olá...",
    image: "/ver-perfil-da-alice-1.png",
    hasVideo: true,
  },
  {
    id: 27,
    name: "Marina",
    description: "Venha ter um momento prazeroso e único! Olá, me chamo...",
    image: "/ver-perfil-da-marina-1.png",
    hasVideo: false,
  },
  {
    id: 28,
    name: "Rafaella",
    description: "Rafaella gata de alto padrão. Olla ,me chamo Rafaella ,...",
    image: "/ver-perfil-da-rafaella.png",
    hasVideo: true,
  },
  {
    id: 29,
    name: "Aurora",
    description: "Novidade no site! Olá! Meu nome é Aurora. Sou uma...",
    image: "/ver-perfil-da-aurora.png",
    hasVideo: false,
  },
  {
    id: 30,
    name: "Daphne",
    description: "Iniciante, pela primeira vez no site! Sou estilo...",
    image: "/ver-perfil-da-daphne.png",
    hasVideo: false,
  },
  // More profiles would continue...
];

export const DivByAnima = (): JSX.Element => {
  return (
    <section className="w-full max-w-[1200px] mx-auto py-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {profiles.slice(0, 30).map((profile) => (
          <Card
            key={profile.id}
            className="overflow-hidden border-0 rounded-md"
          >
            <div className="relative">
              <div
                className="h-[320px] w-full bg-cover bg-center rounded-t-md"
                style={{ backgroundImage: `url(${profile.image})` }}
              />
              {profile.hasVideo && (
                <div className="absolute top-1 left-1">
                  <Badge variant="secondary" className="bg-white/80 p-0.5">
                    <img
                      className="w-[21.34px] h-[15px]"
                      alt="Video available"
                      src="/image.svg"
                    />
                  </Badge>
                </div>
              )}
            </div>
            <CardContent className="p-2">
              <div className="font-['Roboto',Helvetica] text-base">
                <p className="font-bold text-[#fa99ab] mb-1">{profile.name}</p>
                <p className="text-[#f0f0f0] text-sm">{profile.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
